from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'super_secret_key'

@app.route('/')
def index():
    session['counter'] = session.get('counter', 0) + 1
    return render_template('index.html', counter=session['counter'], visits=session.get('visits', 0))

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    return redirect('/')

@app.route('/add_two')
def add_two():
    session['counter'] = session.get('counter', 0) + 2
    return redirect('/')

@app.route('/reset')
def reset():
    session['counter'] = 0
    return redirect('/')

@app.route('/increment', methods=['POST'])
def increment():
    increment = int(request.form['increment'])
    session['counter'] = session.get('counter', 0) + increment
    return redirect('/')

@app.route('/add_one')
def add_one():
    session['counter'] = session.get('counter', 0) + 1
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)
